# Crime Investigation & Case Registry API

This is a backend REST API that manages a police precinct's internal case registry. It handles tracking units, assigning detectives to cases, linking suspects and witnesses, and cataloging case evidence. All core backend code is organized under the `src/` folder.

## Tech Stack
* Python
* FastAPI
* MongoDB
* Beanie ODM (with Motor async driver)
* Playwright (used for automated screenshot capture of responses)

## Project Structure
```
crime-registry/
├── src/
│   ├── models/       # Beanie database schemas
│   ├── routes/       # API endpoint route handlers
│   ├── database.py   # MongoDB client connection lifecycle
│   └── main.py       # FastAPI application entrypoint
├── cui.py            # Console user interface client
├── seed.py           # Database seeder utility
└── README.md
```

## Setup & Running

The API connects to MongoDB locally on the default port `27017`. You can configure a custom connection string by setting the `MONGODB_URI` environment variable.

1. **Populate initial data**:
   ```bash
   python seed.py
   ```
2. **Start the API server**:
   Make sure you run uvicorn with the package path since `main.py` is in the `src` directory:
   ```bash
   python -m uvicorn src.main:app --host 127.0.0.1 --port 8000
   ```
   The interactive Swagger docs will be available at http://127.0.0.1:8000/docs.

3. **Launch the terminal client**:
   Run this in a separate command line window while the API server is active:
   ```bash
   python cui.py
   ```

## Core Endpoints

| HTTP Method | Route Path | Description |
| :--- | :--- | :--- |
| **GET** | `/cases` | Lists all logged cases |
| **GET** | `/cases/{id}/dossier` | Returns a preloaded dossier joining detectives, suspects, witnesses, and evidence |
| **POST** | `/cases` | Logs a new case with an assigned lead detective |
| **PUT** | `/cases/{id}` | Replaces all details of an existing case record |
| **PATCH** | `/cases/{id}/status` | Updates only the status field (e.g. Active, Solved) |
| **DELETE** | `/cases/{id}` | Purges a case and all associated evidence |
| **POST** | `/detectives` | Registers a new investigator |
| **POST** | `/suspects` | Registers a new suspect profile |
| **POST** | `/witnesses` | Registers a new witness profile |
| **POST** | `/cases/{id}/evidence` | Logs an evidence item under a specific case |
| **DELETE** | `/evidence/{id}` | Deletes an evidence item by its ID |

## Data Flow Verification
All CRUD logic has been tested and verified locally by running automated requests against MongoDB via Swagger UI and the Playwright capture scripts. The output response screenshots for the core endpoints are compiled in the separate Report file.
