from beanie import Document
from typing import List, Optional

class Suspect(Document):
    name: str
    alias: Optional[str] = None
    dob: Optional[str] = None # format: YYYY-MM-DD
    criminal_history: List[str] = []
    status: str = "wanted" # wanted / arrested / cleared

    class Settings:
        name = "suspects"
