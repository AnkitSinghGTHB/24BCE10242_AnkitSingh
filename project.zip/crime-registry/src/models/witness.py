from beanie import Document

class Witness(Document):
    name: str
    contact: str
    protection_status: bool = False

    class Settings:
        name = "witnesses"
