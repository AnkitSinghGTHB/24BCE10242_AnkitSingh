from beanie import Document
from pydantic import Field
from typing import Optional

class Unit(Document):
    name: str # e.g. Homicide, Cybercrime, Narcotics, Fraud
    head_detective_id: Optional[str] = None

    class Settings:
        name = "units"
