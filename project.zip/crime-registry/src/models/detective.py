from beanie import Document
from pydantic import Field
from typing import Optional

class Detective(Document):
    name: str
    badge_no: str
    rank: str
    specialization: str
    unit_name: Optional[str] = None

    class Settings:
        name = "detectives"
