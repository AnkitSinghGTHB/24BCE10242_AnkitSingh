from beanie import Document, PydanticObjectId
from pydantic import Field
from datetime import datetime

class Evidence(Document):
    case_id: PydanticObjectId
    type: str # physical / digital / testimony
    description: str
    collected_date: datetime = Field(default_factory=datetime.now)
    chain_of_custody: str

    class Settings:
        name = "evidence"
