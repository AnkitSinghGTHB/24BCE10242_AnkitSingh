from beanie import Document, PydanticObjectId
from pydantic import Field
from typing import List, Optional
from datetime import datetime

class Case(Document):
    case_no: str
    title: str
    crime_type: str
    status: str = "Open" # Open / Active / Solved / Cold
    opened_date: datetime = Field(default_factory=datetime.now)
    lead_detective_id: PydanticObjectId
    unit_name: str
    suspect_ids: List[PydanticObjectId] = []
    detective_ids: List[PydanticObjectId] = [] # case team
    witness_ids: List[PydanticObjectId] = []

    class Settings:
        name = "cases"
