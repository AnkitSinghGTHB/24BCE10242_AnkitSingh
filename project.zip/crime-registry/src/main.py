from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from src.database import init_db
from src.routes import detectives, cases, suspects, witnesses, evidence, units

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield

app = FastAPI(
    title="Crime Investigation & Case Registry API",
    description="Backend API for managing precinct cases, detective allocations, and evidence cataloging.",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(detectives.router)
app.include_router(cases.router)
app.include_router(suspects.router)
app.include_router(witnesses.router)
app.include_router(evidence.router)
app.include_router(units.router)

@app.get("/", tags=["Root"])
async def read_root():
    return {
        "status": "online",
        "system": "Crime Investigation & Case Registry API",
        "documentation": "/docs"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("src.main:app", host="localhost", port=8000, reload=True)
