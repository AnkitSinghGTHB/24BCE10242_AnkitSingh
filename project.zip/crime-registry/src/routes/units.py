from fastapi import APIRouter, HTTPException
from typing import List, Optional
from beanie import PydanticObjectId
from pydantic import BaseModel

from src.models.unit import Unit
from src.models.case import Case

router = APIRouter(prefix="/units", tags=["Units"])

class UnitResponse(BaseModel):
    id: PydanticObjectId
    name: str
    head_detective_id: Optional[str] = None

    class Config:
        json_encoders = {PydanticObjectId: str}

@router.get("", response_model=List[UnitResponse])
async def list_units():
    return await Unit.find_all().to_list()

@router.get("/{name}/cases")
async def list_active_cases_in_unit(name: str):
    return await Case.find(Case.unit_name == name, Case.status == "Active").to_list()
