from fastapi import APIRouter, HTTPException, Body
from fastapi.responses import JSONResponse
from beanie import PydanticObjectId
from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel

from src.models.case import Case
from src.models.detective import Detective
from src.models.unit import Unit
from src.models.suspect import Suspect
from src.models.witness import Witness
from src.models.evidence import Evidence

router = APIRouter(prefix="/cases", tags=["Cases"])

class CaseCreate(BaseModel):
    case_no: str
    title: str
    crime_type: str
    lead_detective_id: PydanticObjectId
    unit_name: str

class CaseResponse(BaseModel):
    id: PydanticObjectId
    case_no: str
    title: str
    crime_type: str
    status: str
    opened_date: datetime
    lead_detective_id: PydanticObjectId
    unit_name: str
    suspect_ids: List[PydanticObjectId]
    detective_ids: List[PydanticObjectId]
    witness_ids: List[PydanticObjectId]

    class Config:
        json_encoders = {PydanticObjectId: str}

class CaseStatusUpdate(BaseModel):
    status: str

class CaseUpdate(BaseModel):
    case_no: str
    title: str
    crime_type: str
    lead_detective_id: PydanticObjectId
    unit_name: str
    status: str

class CaseTransfer(BaseModel):
    unit_name: str

class CaseDetectiveLink(BaseModel):
    detective_id: PydanticObjectId

class DossierResponse(BaseModel):
    id: PydanticObjectId
    case_no: str
    title: str
    crime_type: str
    status: str
    opened_date: datetime
    unit_name: str
    lead_detective: Optional[dict] = None
    case_team: List[dict] = []
    suspects: List[dict] = []
    witnesses: List[dict] = []
    evidence: List[dict] = []

    class Config:
        json_encoders = {PydanticObjectId: str}

@router.post("", response_model=CaseResponse, status_code=201)
async def open_case(payload: CaseCreate):
    officer = await Detective.get(payload.lead_detective_id)
    if not officer:
        raise HTTPException(
            status_code=404, 
            detail="The designated lead detective does not exist in our registry."
        )
        
    precinct_unit = await Unit.find_one(Unit.name == payload.unit_name)
    if not precinct_unit:
        precinct_unit = Unit(name=payload.unit_name)
        await precinct_unit.insert()
        
    clashing_case = await Case.find_one(Case.case_no == payload.case_no)
    if clashing_case:
        raise HTTPException(
            status_code=400, 
            detail=f"Case record with identifier '{payload.case_no}' is already logged in the system."
        )
        
    investigation = Case(
        case_no=payload.case_no,
        title=payload.title,
        crime_type=payload.crime_type,
        lead_detective_id=payload.lead_detective_id,
        unit_name=payload.unit_name,
        detective_ids=[payload.lead_detective_id]
    )
    await investigation.insert()
    return investigation

@router.patch("/{id}/status", response_model=CaseResponse)
async def update_case_status(id: PydanticObjectId, status_payload: CaseStatusUpdate):
    if status_payload.status not in ["Open", "Active", "Solved", "Cold"]:
        raise HTTPException(
            status_code=400, 
            detail="Status must be one of the permitted tags: Open, Active, Solved, or Cold."
        )
        
    investigation = await Case.get(id)
    if not investigation:
        raise HTTPException(
            status_code=404, 
            detail="No case record matches the provided database registry ID."
        )
        
    investigation.status = status_payload.status
    await investigation.save()
    return investigation

@router.put("/{id}", response_model=CaseResponse)
async def full_update_case(id: PydanticObjectId, payload: CaseUpdate):
    investigation = await Case.get(id)
    if not investigation:
        raise HTTPException(
            status_code=404, 
            detail="No case record matches the provided database registry ID."
        )
        
    officer = await Detective.get(payload.lead_detective_id)
    if not officer:
        raise HTTPException(
            status_code=404, 
            detail="The designated lead detective does not exist in our registry."
        )
        
    precinct_unit = await Unit.find_one(Unit.name == payload.unit_name)
    if not precinct_unit:
        precinct_unit = Unit(name=payload.unit_name)
        await precinct_unit.insert()
        
    clashing_case = await Case.find_one(Case.case_no == payload.case_no)
    if clashing_case and clashing_case.id != id:
        raise HTTPException(
            status_code=400, 
            detail=f"Case file number '{payload.case_no}' is already assigned to another active investigation."
        )
        
    investigation.case_no = payload.case_no
    investigation.title = payload.title
    investigation.crime_type = payload.crime_type
    investigation.lead_detective_id = payload.lead_detective_id
    investigation.unit_name = payload.unit_name
    investigation.status = payload.status
    
    if payload.lead_detective_id not in investigation.detective_ids:
        investigation.detective_ids.append(payload.lead_detective_id)
        
    await investigation.save()
    return investigation

@router.delete("/{id}")
async def drop_case(id: PydanticObjectId):
    investigation = await Case.get(id)
    if not investigation:
        raise HTTPException(
            status_code=404, 
            detail="No case file matches the provided database ID."
        )
        
    # TODO: Log archives to separate cold-case collection before deleting
    related_evidence = await Evidence.find(Evidence.case_id == id).to_list()
    for item in related_evidence:
        await item.delete()
        
    await investigation.delete()
    return {
        "message": f"Case file {investigation.case_no} and its associated evidence attachments have been purged."
    }

@router.patch("/{id}/transfer", response_model=CaseResponse)
async def transfer_case_unit(id: PydanticObjectId, transfer_payload: CaseTransfer):
    investigation = await Case.get(id)
    if not investigation:
        raise HTTPException(
            status_code=404, 
            detail="No case registry file matches the provided database ID."
        )
        
    precinct_unit = await Unit.find_one(Unit.name == transfer_payload.unit_name)
    if not precinct_unit:
        precinct_unit = Unit(name=transfer_payload.unit_name)
        await precinct_unit.insert()
        
    investigation.unit_name = transfer_payload.unit_name
    await investigation.save()
    return investigation

@router.post("/{id}/detectives")
async def add_detective_to_case(id: PydanticObjectId, link_payload: CaseDetectiveLink):
    investigation = await Case.get(id)
    if not investigation:
        raise HTTPException(
            status_code=404, 
            detail="No case registry file matches the provided database ID."
        )
        
    officer = await Detective.get(link_payload.detective_id)
    if not officer:
        raise HTTPException(
            status_code=404, 
            detail="No detective was found matching the provided identifier."
        )
        
    if link_payload.detective_id not in investigation.detective_ids:
        investigation.detective_ids.append(link_payload.detective_id)
        await investigation.save()
        
    return {"message": f"Detective {officer.name} successfully assigned to Case {investigation.case_no} team."}

@router.get("/{id}/dossier")
async def get_case_dossier(id: PydanticObjectId):
    investigation = await Case.get(id)
    if not investigation:
        raise HTTPException(
            status_code=404, 
            detail="No case registry file matches the provided database ID."
        )

    def convert_doc(doc):
        return doc.model_dump(mode="json")

    lead_officer = await Detective.get(investigation.lead_detective_id)
    lead_officer_info = convert_doc(lead_officer) if lead_officer else None

    investigation_team = []
    for member_id in investigation.detective_ids:
        member = await Detective.get(member_id)
        if member:
            investigation_team.append(convert_doc(member))

    linked_suspects = []
    for suspect_id in investigation.suspect_ids:
        person = await Suspect.get(suspect_id)
        if person:
            linked_suspects.append(convert_doc(person))

    linked_witnesses = []
    for witness_id in investigation.witness_ids:
        person = await Witness.get(witness_id)
        if person:
            linked_witnesses.append(convert_doc(person))

    evidence_records = await Evidence.find(Evidence.case_id == id).to_list()
    evidence_payload = [convert_doc(item) for item in evidence_records]

    dossier_data = {
        "id": str(investigation.id),
        "case_no": investigation.case_no,
        "title": investigation.title,
        "crime_type": investigation.crime_type,
        "status": investigation.status,
        "opened_date": investigation.opened_date.isoformat(),
        "unit_name": investigation.unit_name,
        "lead_detective": lead_officer_info,
        "case_team": investigation_team,
        "suspects": linked_suspects,
        "witnesses": linked_witnesses,
        "evidence": evidence_payload,
    }
    return JSONResponse(content=dossier_data)

@router.get("", response_model=List[CaseResponse])
async def list_cases():
    return await Case.find_all().to_list()
