from fastapi import APIRouter, HTTPException, Body
from beanie import PydanticObjectId
from typing import List, Optional
from pydantic import BaseModel

from src.models.witness import Witness
from src.models.case import Case

router = APIRouter(tags=["Witnesses"])

class WitnessCreate(BaseModel):
    name: str
    contact: str
    protection_status: bool = False

class WitnessResponse(BaseModel):
    id: PydanticObjectId
    name: str
    contact: str
    protection_status: bool

    class Config:
        json_encoders = {PydanticObjectId: str}

class ProtectionToggle(BaseModel):
    protection_status: bool

@router.post("/witnesses", response_model=WitnessResponse, status_code=201)
async def create_witness(witness_payload: WitnessCreate):
    person = Witness(**witness_payload.dict())
    await person.insert()
    return person

@router.post("/cases/{id}/witnesses")
async def link_witness_to_case(id: PydanticObjectId, witness_id: PydanticObjectId = Body(..., embed=True)):
    investigation = await Case.get(id)
    if not investigation:
        raise HTTPException(status_code=404, detail="Requested case dossier does not exist in registry.")
        
    person = await Witness.get(witness_id)
    if not person:
        raise HTTPException(status_code=404, detail="No witness record matched the specified database ID.")
        
    if witness_id not in investigation.witness_ids:
        investigation.witness_ids.append(witness_id)
        await investigation.save()
        
    return {"message": f"Witness {person.name} successfully linked to Case {investigation.case_no}."}

@router.patch("/witnesses/{id}/protection", response_model=WitnessResponse)
async def toggle_witness_protection(id: PydanticObjectId, protection_payload: ProtectionToggle):
    person = await Witness.get(id)
    if not person:
        raise HTTPException(status_code=404, detail="No witness record matched the specified database ID.")
        
    person.protection_status = protection_payload.protection_status
    await person.save()
    return person

@router.get("/witnesses", response_model=List[WitnessResponse])
async def list_witnesses():
    return await Witness.find_all().to_list()
