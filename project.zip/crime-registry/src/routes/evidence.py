from fastapi import APIRouter, HTTPException, Body
from beanie import PydanticObjectId
from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel

from src.models.evidence import Evidence
from src.models.case import Case

router = APIRouter(tags=["Evidence"])

class EvidenceCreate(BaseModel):
    type: str
    description: str
    chain_of_custody: str

class EvidenceResponse(BaseModel):
    id: PydanticObjectId
    case_id: PydanticObjectId
    type: str
    description: str
    collected_date: datetime
    chain_of_custody: str

    class Config:
        json_encoders = {PydanticObjectId: str}

class CustodyUpdate(BaseModel):
    chain_of_custody: str

@router.post("/cases/{id}/evidence", response_model=EvidenceResponse, status_code=201)
async def log_evidence_for_case(id: PydanticObjectId, item_payload: EvidenceCreate):
    investigation = await Case.get(id)
    if not investigation:
        raise HTTPException(status_code=404, detail="No active case file matches the provided registry ID.")
        
    attachment = Evidence(
        case_id=id,
        type=item_payload.type,
        description=item_payload.description,
        chain_of_custody=item_payload.chain_of_custody
    )
    await attachment.insert()
    return attachment

@router.patch("/evidence/{id}", response_model=EvidenceResponse)
async def update_chain_of_custody(id: PydanticObjectId, custody_payload: CustodyUpdate):
    attachment = await Evidence.get(id)
    if not attachment:
        raise HTTPException(status_code=404, detail="No evidence record found for the provided registry ID.")
        
    attachment.chain_of_custody = custody_payload.chain_of_custody
    await attachment.save()
    return attachment

@router.delete("/evidence/{id}")
async def invalidate_evidence(id: PydanticObjectId):
    attachment = await Evidence.get(id)
    if not attachment:
        raise HTTPException(status_code=404, detail="No evidence record found for the provided registry ID.")
        
    await attachment.delete()
    return {"message": "Evidence record successfully expunged from primary registry."}

@router.get("/cases/{id}/evidence", response_model=List[EvidenceResponse])
async def list_evidence_for_case(id: PydanticObjectId):
    investigation = await Case.get(id)
    if not investigation:
        raise HTTPException(status_code=404, detail="No active case file matches the provided registry ID.")
        
    return await Evidence.find(Evidence.case_id == id).to_list()
