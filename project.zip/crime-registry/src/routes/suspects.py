from fastapi import APIRouter, HTTPException, Path
from beanie import PydanticObjectId
from typing import List, Optional
from pydantic import BaseModel

from src.models.suspect import Suspect
from src.models.case import Case

router = APIRouter(tags=["Suspects"])

class SuspectCreate(BaseModel):
    name: str
    alias: Optional[str] = None
    dob: Optional[str] = None
    criminal_history: List[str] = []
    status: str = "wanted"

class SuspectResponse(BaseModel):
    id: PydanticObjectId
    name: str
    alias: Optional[str] = None
    dob: Optional[str] = None
    criminal_history: List[str] = []
    status: str

    class Config:
        json_encoders = {PydanticObjectId: str}

class SuspectStatusUpdate(BaseModel):
    status: str

@router.post("/suspects", response_model=SuspectResponse, status_code=201)
async def create_suspect(person_payload: SuspectCreate):
    person = Suspect(**person_payload.dict())
    await person.insert()
    return person

@router.post("/cases/{id}/suspects/{suspect_id}")
async def link_suspect_to_case(id: PydanticObjectId, suspect_id: PydanticObjectId):
    investigation = await Case.get(id)
    if not investigation:
        raise HTTPException(status_code=404, detail="Designated case registry file does not exist.")
    
    person = await Suspect.get(suspect_id)
    if not person:
        raise HTTPException(status_code=404, detail="No suspect profile found matching the provided database ID.")
        
    if suspect_id not in investigation.suspect_ids:
        investigation.suspect_ids.append(suspect_id)
        await investigation.save()
        
    return {"message": f"Suspect {person.name} successfully linked to Case {investigation.case_no}."}

@router.delete("/cases/{id}/suspects/{suspect_id}")
async def remove_suspect_from_case(id: PydanticObjectId, suspect_id: PydanticObjectId):
    investigation = await Case.get(id)
    if not investigation:
        raise HTTPException(status_code=404, detail="Designated case registry file does not exist.")
        
    if suspect_id in investigation.suspect_ids:
        investigation.suspect_ids.remove(suspect_id)
        await investigation.save()
        return {"message": f"Suspect was dissociated from Case {investigation.case_no}."}
        
    raise HTTPException(status_code=400, detail="The specified suspect is not linked to this case file.")

@router.get("/suspects/{id}/history")
async def get_suspect_case_history(id: PydanticObjectId):
    person = await Suspect.get(id)
    if not person:
        raise HTTPException(status_code=404, detail="No suspect profile found matching the provided database ID.")
        
    case_involvement = await Case.find(Case.suspect_ids == id).to_list()
    return {
        "suspect": person,
        "cases": case_involvement
    }

@router.patch("/suspects/{id}/status", response_model=SuspectResponse)
async def update_suspect_status(id: PydanticObjectId, status_payload: SuspectStatusUpdate):
    if status_payload.status not in ["wanted", "arrested", "cleared"]:
        raise HTTPException(status_code=400, detail="Invalid status indicator. Permitted: wanted, arrested, cleared.")
        
    person = await Suspect.get(id)
    if not person:
        raise HTTPException(status_code=404, detail="No suspect profile found matching the provided database ID.")
        
    person.status = status_payload.status
    await person.save()
    return person

@router.get("/suspects", response_model=List[SuspectResponse])
async def list_suspects():
    return await Suspect.find_all().to_list()
