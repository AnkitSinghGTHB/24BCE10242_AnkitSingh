from fastapi import APIRouter, HTTPException, Body
from beanie import PydanticObjectId
from typing import Optional, List
from pydantic import BaseModel

from src.models.detective import Detective
from src.models.unit import Unit

router = APIRouter(prefix="/detectives", tags=["Detectives"])

class DetectiveCreate(BaseModel):
    name: str
    badge_no: str
    rank: str
    specialization: str
    unit_name: Optional[str] = None

class DetectiveResponse(BaseModel):
    id: PydanticObjectId
    name: str
    badge_no: str
    rank: str
    specialization: str
    unit_name: Optional[str]

    class Config:
        json_encoders = {PydanticObjectId: str}

class TransferUnit(BaseModel):
    unit_name: str

@router.post("", response_model=DetectiveResponse, status_code=201)
async def create_detective(det_payload: DetectiveCreate):
    badge_collision = await Detective.find_one(Detective.badge_no == det_payload.badge_no)
    if badge_collision:
        raise HTTPException(
            status_code=400, 
            detail=f"Badge code '{det_payload.badge_no}' is already assigned to an active investigator."
        )
    
    if det_payload.unit_name:
        active_unit = await Unit.find_one(Unit.name == det_payload.unit_name)
        if not active_unit:
            new_unit = Unit(name=det_payload.unit_name)
            await new_unit.insert()
            
    officer = Detective(
        name=det_payload.name,
        badge_no=det_payload.badge_no,
        rank=det_payload.rank,
        specialization=det_payload.specialization,
        unit_name=det_payload.unit_name
    )
    await officer.insert()
    return officer

@router.patch("/{id}/unit", response_model=DetectiveResponse)
async def transfer_detective_unit(id: PydanticObjectId, transfer_payload: TransferUnit):
    officer = await Detective.get(id)
    if not officer:
        raise HTTPException(status_code=404, detail="No investigator record found for the provided ID.")
        
    target_unit = await Unit.find_one(Unit.name == transfer_payload.unit_name)
    if not target_unit:
        new_unit = Unit(name=transfer_payload.unit_name)
        await new_unit.insert()
        
    officer.unit_name = transfer_payload.unit_name
    await officer.save()
    return officer

@router.get("", response_model=List[DetectiveResponse])
async def list_detectives():
    # Simple direct query to return all officers currently in the system
    return await Detective.find_all().to_list()
