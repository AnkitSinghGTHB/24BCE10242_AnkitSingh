from motor.motor_asyncio import AsyncIOMotorClient
from beanie import init_beanie
import os

from src.models.unit import Unit
from src.models.detective import Detective
from src.models.suspect import Suspect
from src.models.witness import Witness
from src.models.case import Case
from src.models.evidence import Evidence

MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
DATABASE_NAME = os.getenv("DATABASE_NAME", "crime_registry_db")

async def init_db():
    client = AsyncIOMotorClient(MONGODB_URI)
    await init_beanie(
        database=client[DATABASE_NAME],
        document_models=[Unit, Detective, Suspect, Witness, Case, Evidence]
    )
