import asyncio
import os
import sys
from motor.motor_asyncio import AsyncIOMotorClient
from beanie import init_beanie
from datetime import datetime

# Add the current directory to python path to import models
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.models.unit import Unit
from src.models.detective import Detective
from src.models.suspect import Suspect
from src.models.witness import Witness
from src.models.case import Case
from src.models.evidence import Evidence
from src.database import MONGODB_URI, DATABASE_NAME

async def seed_data():
    print("Connecting to database...")
    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[DATABASE_NAME]
    
    # Drop collections for a clean seed
    print("Dropping existing collections...")
    await db["units"].drop()
    await db["detectives"].drop()
    await db["suspects"].drop()
    await db["witnesses"].drop()
    await db["cases"].drop()
    await db["evidence"].drop()
    
    print("Initializing Beanie...")
    await init_beanie(
        database=db,
        document_models=[Unit, Detective, Suspect, Witness, Case, Evidence]
    )
    
    # Create Units
    print("Creating units...")
    unit_homicide = Unit(name="Homicide")
    unit_cyber = Unit(name="Cybercrime")
    unit_narcotics = Unit(name="Narcotics")
    unit_fraud = Unit(name="Fraud")
    await unit_homicide.insert()
    await unit_cyber.insert()
    await unit_narcotics.insert()
    await unit_fraud.insert()
    
    # Create Detectives
    print("Creating detectives...")
    det1 = Detective(
        name="Sherlock Holmes",
        badge_no="SH123",
        rank="Lead Detective",
        specialization="Forensic Deduction",
        unit_name="Homicide"
    )
    det2 = Detective(
        name="John Watson",
        badge_no="JW456",
        rank="Senior Investigator",
        specialization="Ballistics and Medicine",
        unit_name="Homicide"
    )
    det3 = Detective(
        name="Ada Lovelace",
        badge_no="AL789",
        rank="Special Agent",
        specialization="Cryptography & Network Intrusion",
        unit_name="Cybercrime"
    )
    await det1.insert()
    await det2.insert()
    await det3.insert()
    
    # Set heads of units
    unit_homicide.head_detective_id = det1.badge_no
    unit_cyber.head_detective_id = det3.badge_no
    await unit_homicide.save()
    await unit_cyber.save()
    
    # Create Suspects
    print("Creating suspects...")
    susp1 = Suspect(
        name="James Moriarty",
        alias="Professor Jim",
        dob="1868-09-15",
        criminal_history=["Conspiracy to Murder", "Extortion", "Grand Larceny"],
        status="wanted"
    )
    susp2 = Suspect(
        name="Irene Adler",
        alias="The Woman",
        dob="1872-03-08",
        criminal_history=["Industrial Espionage", "Blackmail"],
        status="cleared"
    )
    await susp1.insert()
    await susp2.insert()
    
    # Create Witnesses
    print("Creating witnesses...")
    wit1 = Witness(
        name="Mrs. Hudson",
        contact="+44 20 7946 0958",
        protection_status=True
    )
    await wit1.insert()
    
    # Create Case
    print("Creating case...")
    case1 = Case(
        case_no="CASE-2026-001",
        title="The Reichenbach Falls Conspiracy",
        crime_type="Homicide",
        status="Active",
        opened_date=datetime.now(),
        lead_detective_id=det1.id,
        unit_name="Homicide",
        suspect_ids=[susp1.id],
        detective_ids=[det1.id, det2.id],
        witness_ids=[wit1.id]
    )
    await case1.insert()
    
    # Create Evidence
    print("Creating evidence...")
    ev1 = Evidence(
        case_id=case1.id,
        type="physical",
        description="A monogrammed silk handkerchief with initials 'J.M.' found near the cliff edge.",
        chain_of_custody="Recovered at crime scene by Dr. Watson on 2026-06-15. Logged into Homicide Locker A under seal #8839."
    )
    ev2 = Evidence(
        case_id=case1.id,
        type="testimony",
        description="Witness Mrs. Hudson reports seeing a tall man in a heavy coat walking towards the falls at 20:30.",
        chain_of_custody="Statement taken by Detective Watson. Audio recording archived in Digital Evidence System under ID DES-9912."
    )
    await ev1.insert()
    await ev2.insert()
    
    print("\nDatabase seeded successfully!")
    print(f"Created unit Homicide with ID {unit_homicide.id}")
    print(f"Created lead detective Sherlock Holmes with ID {det1.id}")
    print(f"Created suspect James Moriarty with ID {susp1.id}")
    print(f"Created witness Mrs. Hudson with ID {wit1.id}")
    print(f"Created case CASE-2026-001 with ID {case1.id}")
    print(f"Created evidence items: {ev1.id}, {ev2.id}")

if __name__ == "__main__":
    asyncio.run(seed_data())
