#!/usr/bin/env python3
"""
Precinct Terminal Console Client
Interacts with the Crime Investigation & Case Registry REST API
"""

import sys
import os
import json
import urllib.request
import urllib.error

API_SERVER_ENDPOINT = "http://127.0.0.1:8000"

# Theme colors
NAVY = "\033[94m"
EMERALD = "\033[92m"
GOLD = "\033[93m"
CRIMSON = "\033[91m"
AQUA = "\033[96m"
BOLD_FONT = "\033[1m"
RESET_STYLE = "\033[0m"

def wipe_terminal():
    os.system("cls" if os.name == "nt" else "clear")

def print_banner(section_title):
    print(f"\n{NAVY}{BOLD_FONT}=================================================={RESET_STYLE}")
    print(f"   {AQUA}{BOLD_FONT}{section_title}{RESET_STYLE}")
    print(f"{NAVY}{BOLD_FONT}=================================================={RESET_STYLE}\n")

def check_backend_availability():
    try:
        connection_test = urllib.request.Request(f"{API_SERVER_ENDPOINT}/", method="GET")
        with urllib.request.urlopen(connection_test, timeout=2) as server_response:
            return server_response.status == 200
    except Exception:
        return False

def dispatch_api_call(http_method, api_route, json_payload=None):
    destination_url = API_SERVER_ENDPOINT + api_route
    raw_bytes = json.dumps(json_payload).encode("utf-8") if json_payload else None
    request_headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    api_request = urllib.request.Request(
        destination_url, 
        data=raw_bytes, 
        headers=request_headers, 
        method=http_method
    )
    try:
        with urllib.request.urlopen(api_request) as server_response:
            return server_response.status, json.loads(server_response.read().decode("utf-8"))
    except urllib.error.HTTPError as http_error:
        try:
            return http_error.code, json.loads(http_error.read().decode("utf-8"))
        except Exception:
            return http_error.code, {"detail": http_error.reason}
    except Exception as connection_error:
        return 500, {"detail": str(connection_error)}

def interactive_case_picker():
    http_status, retrieved_cases = dispatch_api_call("GET", "/cases")
    if http_status != 200 or not retrieved_cases:
        print(f"{CRIMSON}No cases are currently indexed or connection failed.{RESET_STYLE}")
        return None
    
    print("\nIndexed Case Records:")
    for position, case_record in enumerate(retrieved_cases, 1):
        print(f"  [{position}] {BOLD_FONT}{case_record['case_no']}{RESET_STYLE} — {case_record['title']} ({case_record['status']})")
    
    try:
        selection_index = int(input(f"\nSelect case index (1-{len(retrieved_cases)}): "))
        if 1 <= selection_index <= len(retrieved_cases):
            return retrieved_cases[selection_index - 1]
    except ValueError:
        pass
    print(f"{CRIMSON}Selection index out of bounds.{RESET_STYLE}")
    return None

def handle_list_cases():
    wipe_terminal()
    print_banner("CASE REGISTRY - ACTIVE INVESTIGATIONS")
    http_status, registered_cases = dispatch_api_call("GET", "/cases")
    if http_status != 200:
        print(f"{CRIMSON}Registry load failure: {registered_cases.get('detail', 'Unknown error')}{RESET_STYLE}")
        return
    
    if not registered_cases:
        print(f"{GOLD}The central case index is currently empty.{RESET_STYLE}")
        return
        
    print(f"{'No.':<4} {'Case ID Code':<15} {'Investigation Title':<35} {'Category':<12} {'Status':<10}")
    print("-" * 80)
    for index, case_item in enumerate(registered_cases, 1):
        color_coding = EMERALD if case_item['status'] == "Solved" else GOLD if case_item['status'] == "Active" else CRIMSON if case_item['status'] == "Cold" else NAVY
        print(f"{index:<4} {case_item['case_no']:<15} {case_item['title'][:33]:<35} {case_item['crime_type']:<12} {color_coding}{case_item['status']:<10}{RESET_STYLE}")
    print()

def handle_view_dossier():
    wipe_terminal()
    print_banner("INVESTIGATION DOSSIER DETAILS")
    selected_case = interactive_case_picker()
    if not selected_case:
        return
        
    wipe_terminal()
    print_banner(f"DOSSIER INDEX: {selected_case['case_no']}")
    http_status, complete_dossier = dispatch_api_call("GET", f"/cases/{selected_case['id']}/dossier")
    if http_status != 200:
        print(f"{CRIMSON}Dossier retrieval failure: {complete_dossier.get('detail', 'Unknown error')}{RESET_STYLE}")
        return
        
    print(f"{BOLD_FONT}Title:{RESET_STYLE} {complete_dossier['title']}")
    print(f"{BOLD_FONT}Crime Classification:{RESET_STYLE} {complete_dossier['crime_type']}")
    print(f"{BOLD_FONT}Current Status:{RESET_STYLE} {complete_dossier['status']}")
    print(f"{BOLD_FONT}Opening Date:{RESET_STYLE} {complete_dossier['opened_date']}")
    print(f"{BOLD_FONT}Assigned Precinct Unit:{RESET_STYLE} {complete_dossier['unit_name']}")
    
    print(f"\n{AQUA}{BOLD_FONT}--- Case Lead Officer ---{RESET_STYLE}")
    assigned_lead = complete_dossier.get("lead_detective")
    if assigned_lead:
        print(f"  Name: {assigned_lead['name']} (Badge: {assigned_lead['badge_no']})")
        print(f"  Rank: {assigned_lead['rank']} | Specialization: {assigned_lead['specialization']}")
    else:
        print("  No lead officer assigned.")
        
    print(f"\n{AQUA}{BOLD_FONT}--- Investigation Team ---{RESET_STYLE}")
    assigned_team = complete_dossier.get("case_team", [])
    if assigned_team:
        for team_member in assigned_team:
            print(f"  • {team_member['name']} ({team_member['rank']} - Specialization: {team_member['specialization']})")
    else:
        print("  No secondary team members assigned.")
        
    print(f"\n{AQUA}{BOLD_FONT}--- Linked Suspects ---{RESET_STYLE}")
    monitored_suspects = complete_dossier.get("suspects", [])
    if monitored_suspects:
        for suspect in monitored_suspects:
            print(f"  • {suspect['name']} (Alias: {suspect['alias']}, Status: {suspect['status']})")
    else:
        print("  No suspect profiles attached.")

    print(f"\n{AQUA}{BOLD_FONT}--- Material Witnesses ---{RESET_STYLE}")
    material_witnesses = complete_dossier.get("witnesses", [])
    if material_witnesses:
        for witness in material_witnesses:
            protection_status_text = f"{EMERALD}Active Protection{RESET_STYLE}" if witness['protection_status'] else "Standard"
            print(f"  • {witness['name']} (Status: {protection_status_text})")
    else:
        print("  No witness records logged.")

    print(f"\n{AQUA}{BOLD_FONT}--- Cataloged Evidence ---{RESET_STYLE}")
    evidence_records = complete_dossier.get("evidence", [])
    if evidence_records:
        for evidence in evidence_records:
            print(f"  • Registry ID: {BOLD_FONT}{evidence['id']}{RESET_STYLE} | Class: {evidence['type'].upper()}")
            print(f"    Item Description: {evidence['description']}")
            print(f"    Custody Log: {evidence['chain_of_custody']}")
            print()
    else:
        print("  No items currently cataloged in evidence lockup.")

def handle_register_detective():
    wipe_terminal()
    print_banner("NEW INVESTIGATOR REGISTRATION")
    name = input("Enter Officer Name: ")
    badge_no = input("Enter Unique Badge Number: ")
    rank = input("Enter Rank (e.g. Inspector, Sergeant): ")
    specialization = input("Enter Area of Specialization: ")
    unit_name = input("Assign to Precinct Unit (e.g. Homicide): ")
    
    payload = {
        "name": name,
        "badge_no": badge_no,
        "rank": rank,
        "specialization": specialization,
        "unit_name": unit_name
    }
    
    http_status, registration_response = dispatch_api_call("POST", "/detectives", payload)
    if http_status == 201:
        print(f"\n{EMERALD}Officer registered successfully. System ID: {registration_response['id']}{RESET_STYLE}")
    else:
        print(f"\n{CRIMSON}Registration rejected: {registration_response.get('detail', 'Unknown error')}{RESET_STYLE}")

def handle_open_case():
    wipe_terminal()
    print_banner("OPEN NEW INVESTIGATION FILE")
    case_no = input("Enter Unique Case Code (e.g. CASE-2026-999): ")
    title = input("Enter Investigation Title: ")
    crime_type = input("Enter Crime Classification: ")
    lead_det_id = input("Enter Lead Detective Database ID: ")
    unit_name = input("Enter Assigning Precinct Unit: ")
    
    payload = {
        "case_no": case_no,
        "title": title,
        "crime_type": crime_type,
        "lead_detective_id": lead_det_id,
        "unit_name": unit_name
    }
    
    http_status, api_response = dispatch_api_call("POST", "/cases", payload)
    if http_status == 201:
        print(f"\n{EMERALD}Case logged successfully. File ID: {api_response['id']}{RESET_STYLE}")
    else:
        print(f"\n{CRIMSON}Logging failed: {api_response.get('detail', 'Unknown error')}{RESET_STYLE}")

def handle_patch_status():
    wipe_terminal()
    print_banner("MODIFY CASE STATUS (PATCH)")
    target_case = interactive_case_picker()
    if not target_case:
        return
        
    print(f"\nCurrent Status of file is: {BOLD_FONT}{target_case['status']}{RESET_STYLE}")
    print("Select new status assignment:")
    print("  1. Open")
    print("  2. Active")
    print("  3. Solved")
    print("  4. Cold")
    
    menu_selection = input("Enter choice (1-4): ")
    status_mapping = {"1": "Open", "2": "Active", "3": "Solved", "4": "Cold"}
    resolved_status = status_mapping.get(menu_selection)
    if not resolved_status:
        print(f"{CRIMSON}Invalid status assignment selected.{RESET_STYLE}")
        return
        
    status_payload = {"status": resolved_status}
    http_status, api_response = dispatch_api_call("PATCH", f"/cases/{target_case['id']}/status", status_payload)
    if http_status == 200:
        print(f"\n{EMERALD}Case status successfully updated to {resolved_status}!{RESET_STYLE}")
    else:
        print(f"\n{CRIMSON}Status update rejected: {api_response.get('detail', 'Unknown error')}{RESET_STYLE}")

def handle_put_case():
    wipe_terminal()
    print_banner("REPLACE CASE INFORMATION (PUT)")
    target_case = interactive_case_picker()
    if not target_case:
        return
        
    print(f"\nInput replacement details for {target_case['case_no']}:")
    title = input(f"Updated Title [{target_case['title']}]: ") or target_case['title']
    crime_type = input(f"Updated Classification [{target_case['crime_type']}]: ") or target_case['crime_type']
    lead_det_id = input(f"Updated Lead Detective ID [{target_case['lead_detective_id']}]: ") or target_case['lead_detective_id']
    unit_name = input(f"Updated Precinct Unit [{target_case['unit_name']}]: ") or target_case['unit_name']
    
    print("Select Updated Status:")
    print("  1. Open")
    print("  2. Active")
    print("  3. Solved")
    print("  4. Cold")
    menu_selection = input("Enter choice (1-4): ")
    status_mapping = {"1": "Open", "2": "Active", "3": "Solved", "4": "Cold"}
    resolved_status = status_mapping.get(menu_selection) or target_case['status']
    
    payload = {
        "case_no": target_case['case_no'],
        "title": title,
        "crime_type": crime_type,
        "lead_detective_id": lead_det_id,
        "unit_name": unit_name,
        "status": resolved_status
    }
    
    http_status, api_response = dispatch_api_call("PUT", f"/cases/{target_case['id']}", payload)
    if http_status == 200:
        print(f"\n{EMERALD}Case record has been fully replaced/updated!{RESET_STYLE}")
    else:
        print(f"\n{CRIMSON}Replacement operation failed: {api_response.get('detail', 'Unknown error')}{RESET_STYLE}")

def handle_log_evidence():
    wipe_terminal()
    print_banner("CATALOG EVIDENCE FOR INVESTIGATION")
    target_case = interactive_case_picker()
    if not target_case:
        return
        
    print(f"\nCataloging evidence for {target_case['case_no']}:")
    evidence_class = input("Enter classification (physical / digital / testimony): ")
    description = input("Enter description of item: ")
    custody_notes = input("Enter chain of custody log: ")
    
    payload = {
        "type": evidence_class,
        "description": description,
        "chain_of_custody": custody_notes
    }
    
    http_status, api_response = dispatch_api_call("POST", f"/cases/{target_case['id']}/evidence", payload)
    if http_status == 201:
        print(f"\n{EMERALD}Evidence cataloged successfully. Item ID: {api_response['id']}{RESET_STYLE}")
    else:
        print(f"\n{CRIMSON}Cataloging failure: {api_response.get('detail', 'Unknown error')}{RESET_STYLE}")

def handle_delete_evidence():
    wipe_terminal()
    print_banner("PURGE EVIDENCE RECORD (DELETE)")
    target_case = interactive_case_picker()
    if not target_case:
        return
        
    http_status, evidence_set = dispatch_api_call("GET", f"/cases/{target_case['id']}/evidence")
    if http_status != 200 or not evidence_set:
        print(f"{CRIMSON}No cataloged evidence matches this case.{RESET_STYLE}")
        return
        
    print("\nSelect an Evidence Record to Purge:")
    for position, evidence_item in enumerate(evidence_set, 1):
        print(f"  [{position}] ID: {evidence_item['id']} | Class: {evidence_item['type']} - {evidence_item['description'][:30]}...")
        
    try:
        selection_index = int(input(f"\nEnter position selection (1-{len(evidence_set)}): "))
        if 1 <= selection_index <= len(evidence_set):
            target_item = evidence_set[selection_index - 1]
            http_status_del, api_response = dispatch_api_call("DELETE", f"/evidence/{target_item['id']}")
            if http_status_del == 200:
                print(f"\n{EMERALD}Evidence record successfully expunged from primary repository.{RESET_STYLE}")
            else:
                print(f"\n{CRIMSON}Expunge operation rejected: {api_response.get('detail')}{RESET_STYLE}")
            return
    except ValueError:
        pass
    print(f"{CRIMSON}Selection index out of bounds.{RESET_STYLE}")

def handle_register_suspect():
    wipe_terminal()
    print_banner("REGISTER NEW SUSPECT PROFILE")
    name = input("Enter Suspect Full Name: ")
    alias = input("Enter Alias: ")
    dob = input("Enter Date of Birth (YYYY-MM-DD): ")
    prior_records = input("Enter Criminal Records (comma-separated): ")
    criminal_history = [record.strip() for record in prior_records.split(",") if record.strip()]
    
    payload = {
        "name": name,
        "alias": alias,
        "dob": dob,
        "criminal_history": criminal_history,
        "status": "wanted"
    }
    
    http_status, api_response = dispatch_api_call("POST", "/suspects", payload)
    if http_status == 201:
        print(f"\n{EMERALD}Suspect profile created successfully. Profile ID: {api_response['id']}{RESET_STYLE}")
    else:
        print(f"\n{CRIMSON}Profile generation failed: {api_response.get('detail', 'Unknown error')}{RESET_STYLE}")

def main_loop():
    while True:
        wipe_terminal()
        print_banner("PRECINCT CRIME INVESTIGATION CONSOLE")
        
        backend_active = check_backend_availability()
        status_label = f"{EMERALD}ONLINE{RESET_STYLE}" if backend_active else f"{CRIMSON}OFFLINE{RESET_STYLE}"
        print(f"API Server Status: {status_label} (http://127.0.0.1:8000)\n")
        
        if not backend_active:
            print(f"{GOLD}Warning: Rest API backend server is currently offline.{RESET_STYLE}")
            print("Please run the backend using:")
            print(f"  {BOLD_FONT}python -m uvicorn src.main:app --host 127.0.0.1 --port 8000{RESET_STYLE}\n")
            
        print("  1. List Active Case Indexes (GET)")
        print("  2. Fetch Case Dossier Files (GET dossier)")
        print("  3. Register New Investigator (POST)")
        print("  4. Log New Case Investigation (POST)")
        print("  5. Update Investigation Status (PATCH)")
        print("  6. Replace Case File Records (PUT)")
        print("  7. Catalog Case Evidence Items (POST)")
        print("  8. Expunge Case Evidence Items (DELETE)")
        print("  9. Index New Suspect Profile (POST)")
        print("  0. Terminate Console Session")
        
        menu_choice = input("\nEnter choice (0-9): ")
        
        if menu_choice == "0":
            print(f"\n{EMERALD}Terminating session. Goodbye!{RESET_STYLE}")
            sys.exit(0)
            
        if not backend_active and menu_choice in ["1", "2", "3", "4", "5", "6", "7", "8", "9"]:
            print(f"\n{CRIMSON}Operation rejected: API backend server is offline.{RESET_STYLE}")
            input("\nPress Enter to return...")
            continue
            
        if menu_choice == "1":
            handle_list_cases()
        elif menu_choice == "2":
            handle_view_dossier()
        elif menu_choice == "3":
            handle_register_detective()
        elif choice := menu_choice == "4":
            handle_open_case()
        elif menu_choice == "5":
            handle_patch_status()
        elif menu_choice == "6":
            handle_put_case()
        elif menu_choice == "7":
            handle_log_evidence()
        elif menu_choice == "8":
            handle_delete_evidence()
        elif menu_choice == "9":
            handle_register_suspect()
        else:
            print(f"{CRIMSON}Invalid choice selection.{RESET_STYLE}")
            
        input("\nPress Enter to return to primary menu...")

if __name__ == "__main__":
    try:
        main_loop()
    except KeyboardInterrupt:
        print(f"\n\n{EMERALD}Console session interrupted. Goodbye!{RESET_STYLE}")
        sys.exit(0)
